package com.example.mememeet

import android.graphics.Bitmap

data class Meme(val image: String, val tags: List<String>)
